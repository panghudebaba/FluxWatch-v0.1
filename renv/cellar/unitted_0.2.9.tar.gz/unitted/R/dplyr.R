#### select, rename, mutate, ... ####

#' Select/rename variables by name for unitted data.frames & tibbles
#' 
#' @param .data a unitted_data.frame
#' @param ... standard dots, as in \code{\link[dplyr]{rename}}
#' @return a unitted_data.frame after the \code{\link[dplyr]{rename}} operation
#'   
#' @name select
NULL

#' Implements dplyr::select for unitted_data.frames
#' 
#' @importFrom dplyr select
#' @importFrom rlang quos
#' @export
#' 
#' @rdname select
#' @examples
#' dplyr::select(
#'  u(data.frame(x=1:3, y=3:5, z=c("aa", "bb", "cc")), c("X","Y","Z")), 
#'  a=y, x)
select.unitted_data.frame <- function (.data, ...) {
  # 选择数据部分
  selected_data <- dplyr::select(v(.data), ...)
  
  # 获取选择后的列名
  selected_names <- names(selected_data)
  
  # 获取原数据的单位
  original_units <- get_unitbundles(.data)
  
  # 提取所选列的单位
  selected_units <- original_units[selected_names]
  
  # 返回带单位的数据
  u(selected_data, selected_units)
}

#' Implements dplyr::select for unitted_tbl_dfs
#' 
#' @importFrom dplyr select
#' @export
#' 
#' @rdname select
#' @examples
#' dplyr::select(
#'  tibble::as_tibble(u(data.frame(x=1:3, y=3:5, z=c("aa", "bb", "cc")), c("X","Y","Z"))), 
#'  a=y, x)
select.unitted_tbl_df <- select.unitted_data.frame


#' Implements dplyr::rename for unitted_data.frames
#' 
#' @importFrom dplyr rename
#' @importFrom rlang quos
#' @export
#'
#' @rdname select
#' @examples
#' df <- u(data.frame(x=1:3, y=3:5, z=c("aa", "bb", "cc")), c("X","Y","Z"))
#' dplyr::rename(df, a=y, beta=x)
rename.unitted_data.frame <- function (.data, ...) {
  # 重命名数据部分
  renamed_data <- dplyr::rename(v(.data), ...)
  
  # 获取重命名后的列名
  new_names <- names(renamed_data)
  
  # 获取原数据的单位
  units <- get_unitbundles(.data)
  
  # 更新单位名称以匹配新列名
  # 注意：rename 不会改变列的顺序，所以单位向量顺序保持不变
  # 只需要更新名称即可
  names(units) <- new_names
  
  # 返回带单位的数据
  u(renamed_data, units)
}

#' Implements dplyr::rename for unitted_tbl_dfs
#' 
#' @return a unitted_data.frame after the \code{\link[dplyr]{rename}} operation
#' 
#' @importFrom dplyr rename
#' @export
#'
#' @rdname select
#' @examples
#' df <- u(data.frame(x=1:3, y=3:5, z=c("aa", "bb", "cc")), c("X","Y","Z"))
#' dplyr::rename(tibble::as_tibble(df), a=y, beta=x)
rename.unitted_tbl_df <- rename.unitted_data.frame


#' Implements dplyr::mutate for unitted_data.frames
#' 
#' @param .data a unitted_data.frame
#' @param ... standard dots, as in \code{\link[dplyr]{mutate}}
#' @return a unitted_data.frame after the \code{\link[dplyr]{mutate}} operation
#' 
#' @importFrom dplyr mutate
#' @export
#'
#' @name mutate
#' @examples
#' df <- u(data.frame(x=1:3, y=3:5), c("X","Y"))
#' dplyr::mutate(df, z=LETTERS[y], k=x*y)
#' dplyr::mutate(df, z=u(LETTERS[y],'LL'), k=x*y)
mutate.unitted_data.frame <- function (.data, ...) {
  u(dplyr::mutate(v(.data, partial=TRUE), ...))
}

#' Implements dplyr::mutate for unitted_tbl_dfs
#' 
#' @rdname mutate
#' @importFrom dplyr mutate
#' @export
#' @examples
#' dtb <- tibble::as_tibble(u(data.frame(x=1:3, y=3:5), c("X","X")))
#' dplyr::mutate(dtb, z=LETTERS[y], k=x+y)
#' dplyr::mutate(dtb, z=u(LETTERS[y],'LL'), k=x+y)
mutate.unitted_tbl_df <- mutate.unitted_data.frame